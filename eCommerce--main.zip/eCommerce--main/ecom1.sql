-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2023 at 01:10 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom1`
--

-- --------------------------------------------------------

--
-- Table structure for table `bestseller`
--

CREATE TABLE `bestseller` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bestseller`
--

INSERT INTO `bestseller` (`id`, `name`, `price`, `category`, `description`, `gallery`, `created_at`, `updated_at`) VALUES
(1, 'Saree', '600', 'Exclusive Offer 50% off', 'Silk Saree ', 'https://img.freepik.com/free-photo/pretty-beautiful-stylish-woman-purple-suit-walking-city-street-spring-summer-autumn-season-fashion-trend-wearing-hat-holding-purse_285396-7001.jpg', NULL, NULL),
(5, 'Dress', '600', 'Exclusive Offer 50% off', 'Womens Wears', 'https://img.freepik.com/free-photo/pretty-beautiful-stylish-woman-purple-suit-walking-city-street-spring-summer-autumn-season-fashion-trend-wearing-hat-holding-purse_285396-7001.jpg', NULL, NULL),
(6, 'Dress', '600', 'Exclusive Offer 50% off', 'Womens Wears', 'https://raimentz-bucket.s3.us-east-2.amazonaws.com/product_image/RxxN0TESqGTUcrBJL5Qw65oVcbzb9ZzIPCbHUmVW.jpg', NULL, NULL),
(7, 'Dress', '1000', 'Exclusive Offer 50% off', 'Womens Wears', 'https://assets0.mirraw.com/images/10003555/image_zoom.jpeg?1645786708', NULL, NULL),
(8, 'Branded Suite', '17000', 'Exclusive Offer 50% off', 'mens Wears', 'https://i.pinimg.com/originals/72/34/c2/7234c2f6568e375b6cccdf842b34d23c.jpg', NULL, NULL),
(9, 'Wedding Clothe', '15000', 'Exclusive Offer 50% off', 'mens Wears', 'https://i.pinimg.com/236x/0a/1f/cb/0a1fcb39f5fda6eb423218693d5e7b48.jpg', NULL, NULL),
(10, 'Party Frock', '6000', 'Exclusive Offer 50% off', 'Kids Wears', 'https://i.pinimg.com/474x/d5/b1/86/d5b186cd06ca75b1c138ffd7dcad709d.jpg', NULL, NULL),
(11, 'Lehanga', '2900', 'Exclusive Offer 50% off', 'kids Wears', 'https://i.pinimg.com/originals/cc/07/de/cc07deb719748d1b760c2c186edb40e8.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_id`, `user_id`, `created_at`, `updated_at`) VALUES
(5, 19, 1, '2023-10-29 08:35:36', '2023-10-29 08:35:36'),
(6, 17, 1, '2023-10-29 08:38:43', '2023-10-29 08:38:43'),
(7, 33, 9, '2023-10-30 07:29:37', '2023-10-30 07:29:37'),
(10, 17, 15, '2023-10-31 08:55:49', '2023-10-31 08:55:49'),
(11, 17, 15, '2023-10-31 10:24:07', '2023-10-31 10:24:07'),
(27, 50, 18, '2023-11-03 05:34:38', '2023-11-03 05:34:38');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2023_10_18_044617_create_users_table', 1),
(3, '2023_10_18_070600_create_products_table', 1),
(4, '2023_10_18_102159_create_cart_table', 1),
(5, '2023_10_18_121805_create_orders_table', 1),
(6, '2023_11_01_100414_create_bestseller_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `product_id`, `user_id`, `status`, `payment_method`, `payment_status`, `address`, `created_at`, `updated_at`) VALUES
(1, 17, 1, 'pending', 'cash', 'pending', 'rjk', NULL, NULL),
(2, 17, 1, 'pending', 'cash', 'pending', 'rjkt', NULL, NULL),
(3, 19, 1, 'pending', 'cash', 'pending', 'rjkt', NULL, NULL),
(4, 17, 15, 'pending', 'cash', 'pending', 'porbandar', NULL, NULL),
(5, 39, 15, 'pending', 'cash', 'pending', 'rjkt', NULL, NULL),
(6, 51, 18, 'pending', 'cash', 'pending', 'pbr', NULL, NULL),
(7, 53, 18, 'pending', 'cash', 'pending', 'pbr', NULL, NULL),
(8, 53, 18, 'pending', 'cash', 'pending', 'pbr', NULL, NULL),
(9, 51, 18, 'pending', 'Cash on Delivery', 'pending', 'rjk', NULL, NULL),
(10, 50, 18, 'pending', 'Cash on Delivery', 'pending', 'pbr', NULL, NULL),
(11, 48, 18, 'pending', 'cash', 'pending', 'rjk', NULL, NULL),
(12, 103, 18, 'pending', 'cash', 'pending', 'pbr', NULL, NULL),
(13, 50, 20, 'pending', 'cash', 'pending', 'rajkot', NULL, NULL),
(14, 60, 20, 'pending', 'cash', 'pending', 'porbandar', NULL, NULL),
(15, 60, 21, 'pending', 'cash', 'pending', 'rajkot', NULL, NULL),
(16, 60, 22, 'pending', 'cash', 'pending', 'rajkot', NULL, NULL),
(17, 54, 22, 'pending', 'cash', 'pending', 'porbandar', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `category`, `description`, `gallery`, `created_at`, `updated_at`) VALUES
(48, 'hoodie', '300', 'jacket', 'size xl ', 'https://rukminim2.flixcart.com/image/832/832/xif0q/sweatshirt/l/b/n/s-w-05-purple-veirdo-original-imaggtwfbhrhufcy.jpeg?q=70', NULL, NULL),
(50, 'banarasi saree', '5000', 'womens wear saree', 'Trendnding sarees for women get 20% off', 'https://rukminim2.flixcart.com/image/832/832/xif0q/sari/4/o/i/free-hm014red-magmina-unstitched-original-imaguh9fvg7rzs6s.jpeg?q=70', NULL, NULL),
(51, 'bridel lehenga', '9500', 'bridel lehenga for girls', 'New Season offer in bridel lehenga get 30% off Exclusive', 'https://rukminim2.flixcart.com/image/832/832/xif0q/lehenga-choli/l/x/d/free-full-sleeve-lehenga-lehenga-for-women-lehenga-choli-net-original-imaggcwfb3pjh2hf.jpeg?q=70', NULL, NULL),
(52, 'Treditional Dress', '3500', 'Gerogette Dress one piece', 'Floery Women Boutiqe Dress Design  Outfit ', 'https://img.perniaspopupshop.com/catalog/product/k/h/KHUC022211_1.JPG?impolicy=detailimageprod', NULL, NULL),
(53, 'mens regular suit', '4800', ' Solid Suit', 'Designer Mens Slim fit Notched lapel Single Breasted Suit', 'https://rukminim2.flixcart.com/image/416/416/ksru0sw0/tie/1/y/i/free-3-men-s-green-micro-polyester-necktie-set-with-pocket-original-imag69myhtzkjzzw.jpeg?q=70', NULL, NULL),
(54, 'Designer Shirt', '1500', 'men single cotton shirt', 'Exclusive offer on our fashion store ', 'https://rukminim2.flixcart.com/image/832/832/xif0q/shirt/b/4/l/l-frml-st2-vebnor-original-imagqwy4whxwz2dg.jpeg?q=70', NULL, NULL),
(55, 'Short Kurta ', '2999', 'Dark green Cotton l,xl,xxl with heavy art flyler', 'DEELMO mens half sleeve kurta', 'https://rukminim2.flixcart.com/image/832/832/l41n2q80/kurta/n/y/j/s-djj01-digimi-original-imagffdpvhfkjhhh.jpeg?q=70', NULL, NULL),
(56, 'Regular shirt', '400', 'single shirt', 'INDO Prime Sea waves type desinge work', 'https://m.media-amazon.com/images/I/71On2XSPuRL._SY679_.jpg', NULL, NULL),
(59, 'party Dress', '6500', 'pink Kitty fashion', 'Floaral Applique party', 'https://rukminim2.flixcart.com/image/832/832/l1b1oy80/kids-dress/h/0/l/7-8-years-baby-frock-masud-creation-original-imagcwgqfnrtkghb.jpeg?q=70', NULL, NULL),
(60, ' Girls Dress', '1350', 'size -5-7-years\n     ', 'Red sleeveless Dress joy kindly', 'https://s.alicdn.com/@sc04/kf/H2aa3489031424c6194e05a4eb5305195D.jpg_960x960.jpg', NULL, NULL),
(99, 'Casual Jaket', '2800', 'boys jaket set', 'Zolario clothing set for kids', 'https://i.etsystatic.com/35316014/r/il/98c3d8/5211170669/il_794xN.5211170669_ncu7.jpg', NULL, NULL),
(100, 'kids pair', '900', 'Creation Ethnic wear', 'boys wear shirt and pent set', 'https://i.etsystatic.com/43751858/r/il/b7bdcb/5453324188/il_794xN.5453324188_g6l6.jpg', NULL, NULL),
(103, ' Girls Dress', '3999', 'size 12-15-years', 'yellow Dress ', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnc0lopIa_Qw8hkoksTpTVgf6xvUfLQgFXFg&usqp=CAU', NULL, NULL),
(119, 'party frock', '600', 'size l,xl', 'Designer Gograte Flower ', 'https://m.media-amazon.com/images/I/815wM6AbYvL._SY550_.jpg', NULL, NULL),
(120, 'baby dress', '800', 'size 22-25-years', 'Small Cute Flower Derssnaing ', 'https://m.media-amazon.com/images/I/71p9m51QtUL._SY679_.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(8, 'dwarkesh', 'dwarkesh@gmail.com', '$2y$10$tct5Ce.LtrPDp5b6fwK6p.JpNmIZUIp/qEQDCplkUqZDGSkAPyL.q', '2023-10-29 02:28:54', '2023-10-29 02:28:54'),
(18, 'jayshree', 'jayshree@gmail.com', '$2y$10$Sp9KMs8x/9I5UofrRke0Xe3CWW6wztK1ElhbAHyqHLDlIjxOqZDqC', '2023-11-01 11:48:48', '2023-11-01 11:48:48'),
(20, 'jayshree odedara', 'jayshree odedara@gmail.com', '$2y$10$Rx15U413XOuL.5THAUAwFuyVFEAEk3wOMWOt2TRPHU4gDdCATplz6', '2023-11-03 05:41:23', '2023-11-03 05:41:23'),
(21, 'jayshreeodedara', 'jayshreeodedara@gmail.com', '$2y$10$fwA.xCklGrc6dzVkN53O/eFSXlg8rVCZ.Tqai28HOFS5BflmfEfHu', '2023-11-03 06:09:59', '2023-11-03 06:09:59'),
(22, 'odedarashree', 'odedarashree@gmail.com', '$2y$10$y0ixV2/3sNtrZcCBZ0GGU.78L8uWjQFztwAB.ZzuD8SSHn2GEb73q', '2023-11-03 06:28:17', '2023-11-03 06:28:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bestseller`
--
ALTER TABLE `bestseller`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bestseller`
--
ALTER TABLE `bestseller`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
